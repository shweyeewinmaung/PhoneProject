<?php
	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");	
	require_once("includes/dateTime_Helper.php");	
	require_once("includes/shoppingCartFunction.php");
	
	
		$ItemID=$_GET["ItemID"];
		//echo $itemID . "itemID";
		$query="SELECT * FROM item where ItemID" . "=\"$ItemID\"";
		
		$result=mysql_query($query) or die(mysql_error());		
		$num_results=mysql_num_rows($result);	
		$row=mysql_fetch_array($result);
			
		
	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
			<form method="get" action="ItemShoppingCart.php" class="defaultForm">
            <table align="center">
            <tr>
                <td>ItemImage:</td>
                <td><?php echo "<img width='150' height='150' src='" . $row['itemImage'] . "' >";?></td>
            </tr>
            <tr>
                <td>Item ID:</td>
                <td><input type="text" name="ItemID" readonly="true" value="<?php echo $row["ItemID"];?> " /></td>
            </tr>
            <tr>
                <td>Brand Name:</td>
                <td><input type="text" name="BrandName" readonly="true" value="<?php echo $row["BrandName"];?> " /></td>
            </tr>
             <tr>
                <td>Phone Name:</td>
                <td><input type="text" name="ModelNo" readonly="true" value="<?php echo $row["ModelNo"];?> " /></td>
            </tr>
            <tr>
                <td>Color:</td>
                <td><input type="text" name="Color" readonly="true" value="<?php echo $row["Color"];?> " /></td>
            </tr>
             <tr>
                <td>Features:</td>
                <td><input type="text" name="Features" readonly="true" value="<?php echo $row["Features"];?> " /></td>
            </tr>            
             <tr>
                <td>Quantity:</td>
                <td><input type="text" id="Quantity" name="Quantity"/></td>

            </tr>
            <tr>
                <td>Item Price:</td>
                <td><input type="text" name="Price" readonly="true" value="<?php echo $row["Price"];?> " /></td>
            </tr>           
                       
        <tr><td colspan="2"><input type="submit" value="Add to cart" /></td></tr>
    </table>
    </form>    
    <br/>
        <br/>
            <br/>             
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>