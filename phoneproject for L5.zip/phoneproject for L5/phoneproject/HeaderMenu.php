         <ul>
         	<?php
	
			if ($_SESSION['customer']['Role']=="ADMIN")
			{				
				echo "<li><a href=\"AdminIndex.php\">Home</a></li>";
				echo "<li><a href=\"itemRegister.php\">Item Register</a></li>";
				echo "<li><a href=\"itemDisplay.php\">Item Display</a></li>";
				echo "<li><a href=\"PaymentDisplay.php\">PaymentDisplay</a></li>";												
				echo "<li><a href=\"logOut.php\">Log Out</a></li>";								

			}
			else if ($_SESSION['customer']['Role']=="MEMBER")
			{				
				echo "<li style='font-style:italic;'>Logged In as :&nbsp</li>";
				echo "<li style='font-weight:bold;'>";
				echo $_SESSION['customer']['UserName'];
				echo "&nbsp;";
				echo "(" . $_SESSION['customer']['Role'] .")";
				echo "&nbsp;";
				echo "<li><a href=\"Index.php\">Home</a></li>";
				echo "<li><a href=\"member.php\">Sign Up</a></li>";
				echo "<li><a href=\"itemDisplay.php\">Item Display</a></li>";				
				echo "<li><a href=\"logOut.php\">Log Out</a></li>";								

			}
			else
			{
				echo "<li><a href=\"index.php\">Home</a></li> ";
				echo "<li><a href=\"member.php\">Sign Up</a></li>";    
				echo "<li><a href=\"logIn.php\">Log In</a></li>";				
			}
			
			?>	
            	            
		</ul>
