<?php
	session_start();
	
	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");	
	require_once("includes/dateTime_Helper.php");	
	require_once("includes/shoppingCartFunction.php");	
	
	
	$objLogIn = new LogIn();
	
	 if($objLogIn->isMemberLogIn()==false)
		header("Location:LogIn.php");
		
	$size=count($_SESSION['ShoppingCart']);
	
	if($size==0)
	{
		$message="There is no item in the shopping cart to check out.";
		header("Location:info1.php?message=".$message);
	}
	
	for($i=0;$i<$size;$i++)
	{
		$ItemID= $_SESSION['ShoppingCart'][$i]['ItemID'];
		$Quantity= $_SESSION['ShoppingCart'][$i]['Quantity'];
					
		$sql="SELECT * FROM item WHERE ItemID='$ItemID'";
		$result=mysql_query($sql) or (mysql_error());
		$row=mysql_fetch_array($result);
		$Price= $row['Price'];				
		$AvailableQty=$row['Quantity'];
		
	}		
		$objShoppingCart=new ShoppingCart();

		$totalAmount =$objShoppingCart->Get_TotalAmount();
		$amount= $Quantity * $Price;

		
		if(isset($_POST['submitted']))
		{
				if($AvailableQty<$Quantity)
				{
					echo "AvailableQty = " .  $AvailableQty . " & " . "Quantity = " . $Quantity;
					$message="<p><font color='#FF0000'>Can't get more Quantity for Phone</font></p>";
				}
				else
				{
						
			
						$memberID=$objLogIn->getUserID();
						
						$SaleDate=Get_Date($_POST['SaleDate']);
						$SaleID=$_POST['SaleID'];
						$CardNo=$_POST['CardNo'];	
						
						$bookingInsert_sql="INSERT INTO `sale` " . 
							"(SaleID,SaleDate,CustomerID,TotalAmount) " .
							"VALUES('$SaleID','$SaleDate','$memberID','$totalAmount')";
					
						mysql_query($bookingInsert_sql) or die (mysql_error());
						
						$size=count($_SESSION['ShoppingCart']);
					
						for($i=0;$i<$size;$i++)
						{
							$ItemID=$_SESSION['ShoppingCart'][$i]['ItemID'];				
													
							
							$sql="SELECT * FROM `item` WHERE ItemID='$ItemID'";
							//echo "<br>" . $sql . "<br>";
							$result=mysql_query($sql) or die(mysql_error());
							$row=mysql_fetch_array($result);			
					
								
							$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];						
							$Price= $row['Price'];				
			
							$sql="INSERT INTO `saledetail`" . 
							"(SaleID,ItemID,Quantity,Price)" . 
							"VALUES ('$SaleID','$ItemID','$Quantity','$Price')";
							
							mysql_query($sql) or die (mysql_error());
						}
						
						$PaymentID=$_POST['PaymentID'];
						$payment_sql="INSERT INTO `payment`" . 
							"(PaymentID,SaleID,PaymentDate,Amount,CardNo,Status)" . 
							"VALUES ('$PaymentID','$SaleID','$SaleDate','$totalAmount','$CardNo','PAYMENT')";
							mysql_query($payment_sql) or die (mysql_error());
			
						unset($_SESSION['ShoppingCart']);
							?><script>
							alert('Shopping cart is successfully checked out');
							</script>                
							<?php
				}

			
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Mobile Phone Sale and Contract</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onFocus="clearText(this)" onBlur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
		 	          <form name="ItemcheckOut" id="ItemcheckOut" action="ItemcheckOut.php" method="post" class="defaultForm">
                <?php
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>
                <?php
					$grandTotal=$totalAmount+30;
				?>
            <table align="center">
            <input name="SaleID" type="hidden" id="SaleID" value="<?php echo AutoID('sale','SaleID','S_',6);?>" size="50" maxlength="50"/>
            <input name="PaymentID" type="hidden" id="PaymentID" value="<?php echo AutoID('payment','PaymentID','P_',6);?>" size="50" maxlength="50"/>

                <tr>
                    <td>Card No</td>
                    <td><input name="CardNo" type="text" id="CardNo" size="50" maxlength="50"/></td>
                </tr>
                <tr>
                    <td>Booking Date</td>
                    <td><input name="SaleDate" type="text" size="50" id="SaleDate" maxlength="50" value="<?php echo date("d-M-Y")?>" ?></td>
                </tr>
                <tr>
                    <td>Total Amount</td>
                    <td><input name="totalAmount" type="text" size="50" maxlength="50" id="totalAmount" readonly="true" value="<?php echo $totalAmount; ?>"/></td>
                </tr>
            
                <tr>
                    <td><input name="submitted" type="submit" value="Confirm Booking" /></td>
                    <td><input name="reset" type="reset" value="Clear" /></td>
                </tr>
            </table>
                    </form>
                    <br/><br/><br/>
                           
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>