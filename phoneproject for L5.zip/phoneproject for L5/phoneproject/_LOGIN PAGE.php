<?php
session_start();
	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");

	if ($_GET['search'])
	{
		$searchBy=$_GET['searchBy'];
		$searchKey=$_GET['searchKey'];
	
		if (empty($searchKey))
			$sql="SELECT * FROM payment" .
			"ORDER BY 	PaymentID";
		else
			$sql="SELECT * FROM payment " .
			"WHERE $searchBy='$searchKey' ".
			"ORDER BY PaymentID";
	}
	else
	{
		$sql="SELECT * FROM payment " .
		"ORDER BY PaymentID";
	}	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Item").validate(
		{
			rules:
			{
				ItemID:{required: true}
			},
			messages:
			{
				ItemID: "Please enter ItemID"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h1><a href="http://www.templatemo.com" target="_parent">Yellow Blog
                <span>free html css template</span>
            </a></h1>
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
  <form name="PaymentDisplay" id="PaymentDisplay" action="PaymentDisplay.php" method="get">

	<?php
				$message=$_GET['message'];
				
				if (!empty($message))
				{
						echo "<div class='error-Message'>$message</div>";
				}
			?>  

			
			<select name="searchBy" id="searchBy">
			<option value="PaymentID" selected="true">Payment ID</option>
			<option value="	SaleID">SaleID</option>
			</select>
			<input name="searchKey" type="text" id="searchKey"
			size="30"/>
			<input name="search" type="submit" value="Search" />
			<input name="showAll" type="submit" value="Show All" />
			
	</form>
<table width="837" border="0">
<tr>
<th></th>
	<th width="180" height="70">PaymentID</th>
	<th width="150" height="70">SaleID</th>
   	<th width="150" height="70">PaymentDate</th>
	<th width="120" height="70">Amount</th>
	<th width="200" height="70">CardNo</th>
    <th></th>
</tr>

	
<?php
	
	$result=mysql_query($sql) or die(mysql_error());
	$numOfRows=mysql_num_rows($result);
		for($i=0;$i<$numOfRows;$i++)
		{
			$row=mysql_fetch_array($result);
		if ($i%2==0)
		echo "<tr class='alt'>";
		else
		echo "<tr>";
?>

<tr>
	<td><?php echo $row['PaymentID']; ?></td>
	<td><?php echo $row['SaleID']; ?></td>    
	<td><?php echo $row['PaymentDate']; ?></td>
	<td><?php echo $row['Amount']; ?></td>
    <td><?php echo $row['CardNo']; ?></td>
    
    <td width="250" height="44" colspan="2" align="right">
                <?php
                $objLog=new LogIn;
                if ($objLog->isAdminLogIn())
                {
                ?>
                <?php $updateLink="Delivery.php?PaymentID=" . $row['PaymentID']; ?>
                	<a href="<?php echo $updateLink; ?>">Delivery</a>&nbsp;
                
                <?php
                }
                ?>
	</td>
</tr>
            <?php
                }
            ?>
  </table>
</form> 
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>