<?php
	session_start();

    require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");
	
	if (isset($_POST['submitted']))
	{		
		$error=false;
		
		$ItemID=$_POST['ItemID'];
				
		$BrandName=$_POST['BrandName'];
		$ModelNo=$_POST['ModelNo'];
		$Color=$_POST['Color'];
		$Features=$_POST['Features'];
		$Quantity=$_POST['Quantity'];	
		$Price=$_POST['Price'];
		

		$itemImage = $_FILES['itemImage']['name'];	
		
			//	echo $itemImage . " = itemImage";

		$folder = "ItemImage/"; 
		
		if($itemImage) 
		{ 
		  $filename = $folder . $ItemID . "_" . $itemImage; 		  
		
		  $copied = copy($_FILES['itemImage']['tmp_name'], $filename); 
		  
		if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Image.");
		  }
		}

		$query="INSERT INTO " .
				"item" . 
				"(ItemID,BrandName,ModelNo,Color,Features,Quantity,Price,itemImage) ".
				"VALUES" .
				"('$ItemID','$BrandName','$ModelNo','$Color','$Features','$Quantity','$Price','$filename')";
							
		$ret=mysql_query($query) or die(mysql_error());
			if($ret>0)
			{			
		echo "Admin is successfully saved with ItemID : " . $ItemID;
			}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
<form action="itemRegister.php" method="post" name="ItemRegistration" id="ItemRegistration" class="defaultForm" enctype="multipart/form-data">
	<?php
				$message=$_GET['message'];
				
				if (!empty($message))
				{
						echo "<div class='error-Message'>$message</div>";
				}
			?>  
<br/>

<table height="200px">
<tr>
	<td>&nbsp;</td>
    <td><h2>ITEM Registration</h2></td>
</tr>
<tr>
	<td>ItemID</td>
    <td><input type="text" name="ItemID" size="50" value="<?php echo AutoID('item','ItemID','I-',6) ?>" maxlength="20" id="ItemID"/></td>
</tr>

<tr>
	<td>Brand Name</td>
    <td><select name="BrandName">
            <option>Samsaung</option>
            <option>Nokia</option>
            <option>Sony</option>
            <option>Huawei</option>
            <option>HTC</option>
    </select></td>
</tr>
<tr>
	<td>ModelNo</td>
    <td><input type="text" name="ModelNo" size="50" maxlength="20" id="ModelNo"/></td>
</tr>
<tr>
	<td>Color</td>
    <td><input type="radio" name="Color" value="White" id="Color_0" checked="checked"/>White                     
	    <input type="radio" name="Color" value="Black" id="Color_1" />Black
         <input type="radio" name="Color" value="Red" id="Color_2" />Red 
         <input type="radio" name="Color" value="Pink" id="Color_3" />Pink   
         <input type="radio" name="Color" value="Green" id="Color_4" />Green   
          <input type="radio" name="Color" value="Blue" id="Color_5" />Blue   
          <input type="radio" name="Color" value="Yellow" id="Color_6" />Yellow         
         <input type="radio" name="Color" value="Gold" id="Color_7" />Gold   
         <input type="radio" name="Color" value="Sliver" id="Color_8" />Sliver   </td>

</tr>
<tr>
	<td>Features</td>
    <td><input type="text" name="Features" size="50" maxlength="20" id="Features"/></td>
</tr>
<tr>
	<td>Quantity</td>
    <td><input type="text" name="Quantity" size="50" maxlength="20" id="Quantity"/></td>
</tr>
<tr>
	<td>Price</td>
    <td><input type="text" name="Price" size="50" maxlength="20" id="Price"/></td>
</tr>
         <tr>               
             <td>Item Image :</td> 
             <td><input name="itemImage" type="file" id="itemImage"
				size="35" maxlength="35" class="required input_field"/></td>
         </tr>

<tr>
	<td><input type="submit" name="submitted" value="submit"/></td>
    <td><input type="reset" name="reset" value="Clear Data"/></td>
</tr>
</table>
</form>               
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>