<?php
	session_start();
	require_once("includes/db.php");
	require_once("includes/function.php");
	require_once("includes/logInFunction.php");
	
	if(isset($_POST['submitted']))
	{
		$UserName=$_POST['UserName'	];
		$Password=$_POST['Password'];
		
		$objLogIn=new LogIn;
		$logInOK=$objLogIn->isLogInOK($UserName,$Password); /*MemberIndex.php*/
		
		if($logInOK==false)
		{
			$error=true;
			$message="<font color='red'>***Incorrect UserName and Password***</font>";
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#login").validate(
		{
			rules: {
					UserName:
					{required: true},
					Password:
					{required: true}
					},
			messages:
				{
					UserName: "<font color='red'>***Please type UserName!***</font>",
					Password: "<font color='red'>***Please type Password!***</font>"
				}
		});
	});
</script>

<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
                    <form action="LogIn.php" method="post" name="LogIn" id="login" class="defaultForm" enctype="multipart/form-data">
                     <?php
                                    if (!empty($message))
                                    {
                                        if ($error)
                                            echo "<div class='error-Message'>$message</div>";
                                        else
                                            echo "<div class='success-Message'>$message</div>";
                                    }				
                                    ?>   
                    <table align="center" height="200px">
                    <tr>
                        <td>User Name</td>
                        <td><input type="text" name="UserName" size="50" maxlength="20" id="UserName"/></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><input type="password" name="Password" size="50" maxlength="20" id="Password"/></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="submitted" value="Log In"/></td>
                        <td><input type="reset" name="reset" value="Clear Data"/></td>
                    </tr>
                    </table>
                    </form>  
                             
                    
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>