-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2013 at 03:29 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phone4everyonedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE IF NOT EXISTS `contract` (
  `ContractID` varchar(10) NOT NULL,
  `ContractDate` varchar(10) NOT NULL,
  `ContractDuration` varchar(20) NOT NULL,
  `ItemID` varchar(10) NOT NULL,
  PRIMARY KEY (`ContractID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contract`
--

INSERT INTO `contract` (`ContractID`, `ContractDate`, `ContractDuration`, `ItemID`) VALUES
('CT-000001', '2013-07-08', '30', 'I-000001');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `CustomerID` varchar(10) NOT NULL,
  `CustomerName` varchar(30) NOT NULL,
  `CustomerAddress` varchar(50) NOT NULL,
  `CustomerEmail` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `BankAccountNumber` varchar(20) NOT NULL,
  `SortCode` varchar(10) NOT NULL,
  `UserName` varchar(10) NOT NULL,
  `Role` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `CustomerName`, `CustomerAddress`, `CustomerEmail`, `Password`, `BankAccountNumber`, `SortCode`, `UserName`, `Role`) VALUES
('C-000001', 'Shwe', 'Yee', 'shweyee@gmail.com', 'yee', 'B0012121', '', 'shwe', 'ADMIN'),
('C-000002', 'Mon', 'Mon', 'mon@gmail.com', 'aa', 'C25565656', '', 'aa', 'MEMBER');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
  `DeliveryID` varchar(10) NOT NULL,
  `DeliveryDate` varchar(10) NOT NULL,
  `PaymentID` varchar(10) NOT NULL,
  PRIMARY KEY (`DeliveryID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`DeliveryID`, `DeliveryDate`, `PaymentID`) VALUES
('D-000001', '2013-07-07', 'P_000001');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `ItemID` varchar(10) NOT NULL,
  `BrandName` varchar(10) NOT NULL,
  `ModelNo` varchar(20) NOT NULL,
  `Color` varchar(20) NOT NULL,
  `Features` varchar(30) NOT NULL,
  `Quantity` varchar(30) NOT NULL,
  `Price` varchar(30) NOT NULL,
  `itemImage` varchar(100) NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ItemID`, `BrandName`, `ModelNo`, `Color`, `Features`, `Quantity`, `Price`, `itemImage`) VALUES
('I-000001', 'Sony', 'XPEPIA', 'Pink', 'Touch', '30', '259000', 'ItemImage/I-000001_so8.jpg'),
('I-000002', 'Nokia', '920', 'Blue', 'Touch', '20', '320000', 'ItemImage/I-000002_s6.jpg'),
('I-000003', 'Samsaung', 'IP324', 'Black', 'Touch', '21', '291000', 'ItemImage/I-000003_5.jpg'),
('I-000004', 'Nokia', 'N0054', 'Green', 'Keypad', '45', '264000', 'ItemImage/I-000004_s3.jpg'),
('I-000005', 'HTC', 'Butterfly', 'Black', 'Touch', '10', '500000', 'ItemImage/I-000005_t6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `PaymentID` varchar(10) NOT NULL,
  `SaleID` varchar(10) NOT NULL,
  `PaymentDate` varchar(10) NOT NULL,
  `Amount` varchar(10) NOT NULL,
  `CardNo` varchar(10) NOT NULL,
  `Status` varchar(10) NOT NULL,
  PRIMARY KEY (`PaymentID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `SaleID`, `PaymentDate`, `Amount`, `CardNo`, `Status`) VALUES
('P_000001', 'S_000001', '2013-07-07', '1359000', 'A12413', 'PAYMENT'),
('P_000002', 'S_000002', '2013-07-08', '1391000', 'H3245', 'PAYMENT');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE IF NOT EXISTS `sale` (
  `SaleID` varchar(10) NOT NULL,
  `SaleDate` varchar(10) NOT NULL,
  `CustomerID` varchar(10) NOT NULL,
  `TotalAmount` varchar(10) NOT NULL,
  PRIMARY KEY (`SaleID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`SaleID`, `SaleDate`, `CustomerID`, `TotalAmount`) VALUES
('S_000001', '2013-07-07', 'C-000002', '1359000'),
('S_000002', '2013-07-08', 'C-000002', '1391000');

-- --------------------------------------------------------

--
-- Table structure for table `saledetail`
--

CREATE TABLE IF NOT EXISTS `saledetail` (
  `SaleID` varchar(10) NOT NULL,
  `ItemID` varchar(10) NOT NULL,
  `Quantity` varchar(10) NOT NULL,
  `Price` varchar(10) NOT NULL,
  PRIMARY KEY (`SaleID`,`ItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `saledetail`
--

INSERT INTO `saledetail` (`SaleID`, `ItemID`, `Quantity`, `Price`) VALUES
('S_000001', 'I-000001 ', '3', '259000'),
('S_000001', 'I-000003 ', '2', '291000'),
('S_000002', 'I-000001 ', '2', '259000'),
('S_000002', 'I-000003 ', '3', '291000');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
