<?php
	session_start();

	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");
	

	if (isset($_POST['submitted']))
	{	
		$ItemID=$_POST['ItemID'];
				
		$BrandName=$_POST['BrandName'];
		$ModelNo=$_POST['ModelNo'];
		$Color=$_POST['Color'];
		$Features=$_POST['Features'];
		$Quantity=$_POST['Quantity'];	
		$Price=$_POST['Price'];
		
		$room_sql="Update `item` " .
			"SET BrandName='$BrandName', ModelNo='$ModelNo', Color='$Color', Features='$Features', Quantity='$Quantity',  Price='$Price' " .
			"WHERE ItemID='$ItemID'";
			
	
		mysql_query($room_sql) or die(mysql_error());	
		
		$message="\"" . $ItemID . "\" is successfully updated.";
		
//		header("Location:info.php?message=" . $message);
						  
	}
	else
	{
		$ItemID=$_GET['ItemID'];
	
		$sql="SELECT * FROM item " .
				"WHERE ItemID='$ItemID'";
				
		$result=mysql_query($sql) or die(mysql_error());
		$noOfRecords=mysql_num_rows($result);
		
		if ($noOfRecords<1) 
		{
			die ("Error occured! No corresponding records for itemID : $ItemID");
		}
		
		$row=mysql_fetch_array($result);
		$BrandName=$row['BrandName'];
		$ModelNo=$row['ModelNo'];
		$Color=$row['Color'];
		$Features=$row['Features'];
		$Quantity=$row['Quantity'];	
		$Price=$row['Price'];
		
		$white='unchecked';
		$black='unchecked';
		$red='unchecked';		
		$pink='unchecked';
		$green='unchecked';
		$blue='unchecked';
		$yellow='unchecked';
		$gold='unchecked';
		$sliver='unchecked';
		
		if ($Color==="White")
		{
			$white='checked';
		}
		else if ($Color==="Black")
		{
			$black='checked';
		}
		else if ($Color==="Red")
		{
			$red='checked';
		}
		
		else if ($Color==="Pink")
		{
			$pink='checked';
		}
		else if ($Color==="Green")
		{
			$green='checked';
		}
		else if ($Color==="Blue")
		{
			$blue='checked';
		}
		else if ($Color==="Yellow")
		{
			$yellow='checked';
		}
		
		else if ($Color==="Gold")
		{
			$gold='checked';
		}
		else 
		{			
			$sliver='checked';
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Item").validate(
		{
			rules:
			{
				ItemID:{required: true}
			},
			messages:
			{
				ItemID: "Please enter ItemID"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
		 	 <form name="Item" id="Item" action="ItemUpdate.php" method="post" class="defaultForm" enctype="multipart/form-data">
			 <?php				
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?> 
          <table height="500px">
                         
                <tr>
                <td>Room ID :</td>
	            <td><input name="ItemID" type="text" id="ItemID"
						size="50" maxlength="50" value="<?php echo $ItemID; ?>" readonly="true"  /></td>
                </tr>
                <tr><td>BrandName :</td>
                <td><input name="BrandName" type="text" id="BrandName"
						size="50" maxlength="50" value="<?php echo $BrandName; ?>" />
</td>
                </tr>
                 <tr><td>PhoneName :</td>
                <td><input name="ModelNo" type="text" id="ModelNo"
						size="50" maxlength="50" value="<?php echo $ModelNo; ?>" />    </td>
                </tr>         
                        
                <tr>
                    <td>Color</td>
                    <td><input type="radio" name="Color" value="White"  id="Color_0" <?php echo $white; ?>checked="checked"/>White                     
                        <input type="radio" name="Color" value="Black" id="Color_1" <?php echo $black; ?>/>Black
                        <input type="radio" name="Color" value="Red" id="Color_2" <?php echo $red; ?>/>Red 
                        <input type="radio" name="Color" value="Pink"  id="Color_0" <?php echo $pink; ?>/>Pink                     
                        <input type="radio" name="Color" value="Green" id="Color_1" <?php echo $green; ?>/>Green
                        <input type="radio" name="Color" value="Blue" id="Color_2" <?php echo $blue; ?>/>Blue                          
                        <input type="radio" name="Color" value="Yellow" id="Color_2" <?php echo $yellow; ?>/>Yellow
                        <input type="radio" name="Color" value="Gold" id="Color_3" <?php echo $gold; ?>/>Gold   
                        <input type="radio" name="Color" value="Sliver" id="Color_4" <?php echo $sliver; ?>/>Sliver   </td>
                </tr>
                 <tr><td>Features :</td>
                <td><input name="Features" type="text" id="Features"
						size="50" maxlength="50" value="<?php echo $Features; ?>" />    </td>
                </tr>     
                <tr><td>Quantity :</td>
                <td><input name="Quantity" type="text" id="Quantity"
						size="50" maxlength="50" value="<?php echo $Quantity; ?>" />    </td>
                </tr>    
                <tr><td>Price :</td>
                <td><input name="Price" type="text" id="Price"
						size="50" maxlength="50" value="<?php echo $Price; ?>" />
</td>
                </tr>
                    
                <tr><td><input name="submitted" type="submit" value="Update" /></td>
					<td><input name="reset" type="reset" value="Clear" /></td>
                </tr>
          </table>                	               
            </form>      
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>