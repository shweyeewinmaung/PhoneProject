<?php
	session_start();	//starting "Session"

	require_once("includes/db.php");		
	require_once("includes/function.php");
	require_once("includes/shoppingCartFunction.php");
	require_once("includes/logInFunction.php");	
	

	$objLogIn=new LogIn();
	
	if($objLogIn->isMemberLogIn()==false)
	header("Location:LogIn.php");
	
	$shoppingCart = new ShoppingCart();

	
	$ItemID=$_GET['ItemID'];
	$BrandName=$_GET['BrandName'];	
	$ModelNo=$_GET['ModelNo'];
	$Color=$_GET['Color'];	
	$Features=$_GET['Features'];
	$Quantity=$_GET['Quantity'];
	$Price=$_GET['Price'];	
	$itemImage=$_GET['itemImage'];	
	
	$statusOK=$shoppingCart->Insert($ItemID, $Quantity);

		
	if($_GET['Action']=="Remove")
	{
		$ItemID=$_GET['ItemID'];
		$shoppingCart->Remove($ItemID);
	}
	else if ($_GET['Action']=="Clear")
	{
		//Function Call to Clear "ShoppingCart"
		$shoppingCart->Clear();
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h1><a href="http://www.templatemo.com" target="_parent">Yellow Blog
                <span>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<li style='font-style:italic;'>Logged In as :&nbsp</li>";
								echo "<li style='font-weight:bold;'>";
								echo $_SESSION['customer']['UserName'];
								echo "&nbsp;";
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "&nbsp;";
							}
							?>
                </span>
            </a></h1>
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
	</div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
        	   <table align="center" class="shoppingCart">                
				<?php
					$size=count($_SESSION['ShoppingCart']);
					
					$totalAmount=0;
					
					if ($size==0)
					{
				?>
                	<td style="width:600px;text-align:center;">
						<h3>Your Shopping Cart is empty.</h3>
                    </td>
                    <?php
					}//end of "if"


					for($i=0;$i<$size;$i++)
					{			
						$ItemID=$_SESSION['ShoppingCart'][$i]['ItemID'];//
						$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];								
						
						$sql="SELECT * FROM item WHERE ItemID='$ItemID'";	
						$result=mysql_query($sql) or die(mysql_error());
						$row=mysql_fetch_array($result);
						
						$amount= $Quantity * $row['Price'];
						$totalAmount+=$amount;
						
						if ($i%2==0)
							echo "<tr>";
						else
							echo "<tr class='alt'>";
                ?>
                    <td>                        
                        <table class="sub-shoppingCart">
                            <tr>
                                <td style="width:100px;">
                                    <img src="<?php echo $row['itemImage']; ?>" width="100px" height="100px"/>
                                </td>
                                <td style="vertical-align:top;text-align:left;padding:0 5 0 10;">
                                    <p>
                                     BrandName: <strong><?php echo $row['BrandName']; ?></strong><br/>
                                     ModelNo: <strong><?php echo $row['ModelNo']; ?></strong><br/>                                   
                                     Color: <strong><?php echo $row['Color']; ?></strong><br/>                                   
                                     Features: <strong><?php echo $row['Features']; ?></strong><br/>                                   
                                     Quantity : <strong><?php echo $Quantity; ?></strong><br/>      
                                     
                                     Price:<strong> <?php echo $row['Price']; ?></strong><br/>                                                                            
                                     Amount : <strong><?php echo $amount; ?></strong><br/>
                                     <a href="ItemShoppingCart.php?ItemID=<?php echo $ItemID; ?>&Action=Remove">Remove</a>
                                    </p>
                                </td>
                            </tr>    
                        </table>
                    </td>
                  </tr>
            <?php             
                    }
            ?>
            	<tr>
                	<td colspan="2" style="text-align:right;padding:3px;">
	                    <a href="ItemcheckOut.php">Confirm Order</a>&nbsp;
                    	<a href="ItemShoppingCart.php?Action=Clear">Clear</a>&nbsp;
                    	<strong>Total Amount : <?php echo $totalAmount; ?></strong>
                    </td>
                </tr>
            </table>      
            <br/><br/><br/>   
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>