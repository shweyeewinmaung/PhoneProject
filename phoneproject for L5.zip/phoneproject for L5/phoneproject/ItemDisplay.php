<?php
session_start();
	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");

	if ($_GET['search'])
	{
		$searchBy=$_GET['searchBy'];
		$searchKey=$_GET['searchKey'];
	
		if (empty($searchKey))
			$sql="SELECT * FROM item" .
			"ORDER BY 	ItemID";
		else
			$sql="SELECT * FROM item " .
			"WHERE $searchBy='$searchKey' ".
			"ORDER BY ItemID";
	}
	else
	{
		$sql="SELECT * FROM item " .
		"ORDER BY ItemID";
	}	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
  <form name="ItemSearch" id="ItemSearch" action="ItemDisplay.php" method="get">

	<?php
				$message=$_GET['message'];
				
				if (!empty($message))
				{
						echo "<div class='error-Message'>$message</div>";
				}
			?>  

			
			<select name="searchBy" id="searchBy">
			<option value="ItemID" selected="true">Item ID</option>
			<option value="	BrandName">BrandName</option>
            <option value="	Color">Color</option>
			</select>
			<input name="searchKey" type="text" id="searchKey"
			size="30"/>
			<input name="search" type="submit" value="Search" />
			<input name="showAll" type="submit" value="Show All" />
			
	</form>
<table border="0">
<tr>
<th></th>
	<th width="100" height="70">ItemID</th>
	<th width="100" height="70">BrandName</th>
   	<th width="100" height="70">ModelNo</th>
	<th width="100" height="70">Color</th>
	<th width="150" height="70">Features</th>
    <th height="70" >Quantity</th>
    <th height="70">Price</th>
    <th></th>
</tr>

	
<?php
	
	$result=mysql_query($sql) or die(mysql_error());
	$numOfRows=mysql_num_rows($result);
		for($i=0;$i<$numOfRows;$i++)
		{
			$row=mysql_fetch_array($result);
		if ($i%2==0)
		echo "<tr class='alt'>";
		else
		echo "<tr>";
?>

<tr>
    <td><img src="<?php echo $row['itemImage']; ?>" width="150px" height="150px"/></td> 
	<td><?php echo $row['ItemID']; ?></td>
	<td><?php echo $row['BrandName']; ?></td>    

	<td><?php echo $row['ModelNo']; ?></td>
	<td><?php echo $row['Color']; ?></td>
    <td><?php echo $row['Features']; ?></td>
    <td><?php echo $row['Quantity']; ?></td>
    <td width="121"><?php echo $row['Price']; ?></td>
    
    <td width="200" height="44" colspan="2" align="right">
                <?php
                $objLog=new LogIn;
                if ($objLog->isAdminLogIn())
                {
                ?>
                <?php $updateLink="ItemUpdate.php?ItemID=" . $row['ItemID']; ?>
                	<a href="<?php echo $updateLink; ?>"><input type="submit" value="Update"/></a>&nbsp;
               
                <?php $deleteLink="ItemDelete.php?ItemID=" . $row['ItemID']; ?>
               		<a href="<?php echo $deleteLink; ?>"><input type="submit" value="Delete"/></a>&nbsp;
                <?php
                }
                if ($objLog->isMemberLogIn())
					{
					?>
			                <?php $updateLink="Contract.php?ItemID=" . $row['ItemID']; ?>
                	<a href="<?php echo $updateLink; ?>"></a>&nbsp;
                   

<?php $itemdisplayLink="ItemDisplayDetail.php?ItemID=" . $row['ItemID']; ?>
               		<a href="<?php echo $itemdisplayLink; ?>"><input type="submit" value="Item Display Detail>>"/></a>&nbsp;

	<?php
					}
                ?>
	</td>
</tr>
            <?php
                }
            ?>
  </table>
</form>
                           
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>