<?php
	session_start();

	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");
	
		$PaymentID=$_GET['PaymentID'];
	
		$sql="SELECT * FROM payment " .
				"WHERE PaymentID='$PaymentID'";
				
		$result=mysql_query($sql) or die(mysql_error());

	if (isset($_POST['submitted']))
	{	
		$PaymentID=$_POST['PaymentID'];
		$DeliveryID=$_POST['DeliveryID'];
		$DeliveryDate=date("Y-m-d",strtotime($_POST['DeliveryDate']));
		
		$query="INSERT INTO " .
				"delivery" . 
				"(DeliveryID,DeliveryDate,PaymentID) ".
				"VALUES" .
				"('$DeliveryID','$DeliveryDate','$PaymentID')";
							
		mysql_query($query) or die(mysql_error());
		
		$message="\"" . $DeliveryID . "\" is successfully saved.";
		
						  
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Contract").validate(
		{
			rules:
			{
				ContractDuration:{required: true}
			},
			messages:
			{
				ContractDuration: "Please enter ContractDuration"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h3><font color="#FF0000">Phone4Everyone Mobile Phone Sale System</font></h3>
                <?php
                if ($_SESSION['customer']['Role']=="ADMIN")
							{				
								echo "<font-style:italic;'>Logged In as :";
								echo "<b>";
								echo $_SESSION['customer']['UserName'];
								echo "(" . $_SESSION['customer']['Role'] .")";
								echo "</b>";
							}
							?>
                  
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
            
		 	 <form name="Delivery" id="Delivery" action="Delivery.php" method="post" class="defaultForm" enctype="multipart/form-data">
			 <?php				
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?> 
          <table height="500px">
                         
                <tr><td>DeliveryID :</td>
                <td><input name="DeliveryID" type="text" id="DeliveryID" value="<?php echo AutoID("delivery","DeliveryID","D-",6);?>" readonly="true" /></td>
                </tr>
                <tr>
                <td>PaymentID :</td>
	            <td><input name="PaymentID" type="text" id="PaymentID" value="<?php echo $PaymentID; ?>" readonly="true"  /></td>
                </tr>

                 <tr><td>DeliveryDate :</td>
                <td>        <input name="DeliveryDate" type="text" id="DeliveryDate" readonly="true" value="<?php echo date("d-M-Y")?>" 	                    onfocus="showCalender(calender,this)"/>
    </td>
                </tr>         
                        

                    
                <tr><td><input name="submitted" type="submit" value="Delivery" /></td>
					<td><input name="reset" type="reset" value="Clear" /></td>
                </tr>
          </table>                	               
            </form>
                           
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>