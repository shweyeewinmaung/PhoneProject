<?php

	session_start();
	require_once("includes/db.php");
	require_once("includes/function.php");
	
if(isset($_POST['submitted']))
{
	$error=false;
	
	$CustomerID=$_POST['CustomerID'];
	$CustomerName=$_POST['CustomerName'];
	$CustomerAddress=$_POST['CustomerAddress'];
	$CustomerEmail=$_POST['CustomerEmail'];
	$Password=$_POST['Password'];
	$BankAccountNumber=$_POST['BankAccountNumber'];
	$SortCode=$_POST['SortCode'];
	$UserName=$_POST['UserName'];

	$UserName_sql="SELECT * FROM customer WHERE UserName='$UserName'";
	
	$result=mysql_query($UserName_sql) or die(mysql_error());
	
	$NoOfRows=mysql_num_rows($result);
	
	if($NoOfRows>0)
	{
	  $message="User Name is already exited";
	  header("Location:Member.php?message = " . $message);
	  exit;
	}
	
	$memberInsert_sql="INSERT INTO customer " .
	"(CustomerID,CustomerName,CustomerAddress,CustomerEmail,Password,BankAccountNumber,SortCode,UserName,Role)" .
	"VALUES ('$CustomerID','$CustomerName','$CustomerAddress','$CustomerEmail','$Password','$BankAccountNumber','$SortCode','$UserName','MEMBER')";
	
	mysql_query($memberInsert_sql) or die(mysql_error());
	
	
	$message="Successfully saved with MemberID =" . $CustomerID;
	header("Location:member.php?message = " . $message);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>yellow blog template, free html css layout</title>
<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"> </script>
<script type="text/javascript" src="JavaScript/jquery.js"/></script>
<script type="text/javascript" src="JavaScript/jquery.validate.js"/></script>
<link href="CSS/CSS.css" rel="stylesheet" type="text/css" />
</head>
<body>

<script type="text/javascript">
	$(function()
	{
		$("#Item").validate(
		{
			rules:
			{
				ItemID:{required: true}
			},
			messages:
			{
				ItemID: "Please enter ItemID"				
							
			},
				errorElement: "div" 
		});
	});
	
</script>
<div id="templatemo_site_title_bar_wrapper">
	<div id="templatemo_site_title_bar">
	    <div id="site_title">
            <h1><a href="http://www.templatemo.com" target="_parent">Yellow Blog
                <span>free html css template</span>
            </a></h1>
        </div>
        
        <div id="search_box">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="Search" value="" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div>
    
    </div>
    
</div>

<div id="templatemo_menu_wrapper">
	<div id="templatemo_menu">
			<?php include_once("HeaderMenu.php") ?>
    </div>
</div> 

<div id="templatemo_content_wrapper_outer">

	<div id="templatemo_content_wrapper_inner">
    
    	<div id="templatemo_content_wrapper">
        	
            <div id="templatemo_content"><!-- end of main column --><!-- end of side column -->
                    <form action="Member.php" name="MemberRegistration" id="member" method="post">
                        <?php
                                    $message=$_GET['message'];
                                    
                                    if (!empty($message))
                                    {
                                            echo "<div class='error-Message'>$message</div>";
                                    }
                                ?>  
                    <br/>
                    
                    <table>
                    <tr>
                        <td>
                            <label>CustomerID</label></td>
                        <td>	<input type="text" name="CustomerID" id="CustomerID" size="50" readonly="true" maxlength="20" value="<?php echo AutoID('customer','CustomerID','C-',6) ?>"/></td>
                    </tr>
                    <tr>
                        <td>
                          <label>Customer Name</label>
                        </td>	
                        <td>
                            <input type="text" name="CustomerName" id="CustomerName" size="50" maxlength="30"/>
                        </td>
                    </tr>
                    <tr>
                         <td>
                              <label>Customer	Address</label>
                         </td>
                         <td>
                             <input type="text" name="CustomerAddress" id="CustomerAddress" size="50" maxlength="20"/>
                         </td>
                    </tr>
                    <tr>
                         <td>
                               <label> CustomerEmail</label>
                         </td>
                         <td>
                              <input type="text" name="CustomerEmail" id="CustomerEmail" size="50"b maxlength="50"/>
                         </td>
                    </tr>
                    <tr>
                         <td>
                             <label>Password</label>
                         </td>
                         <td>
                              <input type="password" name="Password" id="Password" size="50" maxlength="20"/>
                         </td>
                    </tr>
                    <tr>
                         <td>
                             <label>Bank Account Number</label>
                         </td>
                         <td>
                              <input type="text" name="BankAccountNumber" id="BankAccountNumber" size="50" maxlength="20"/> 
                         </td>
                    </tr>
                    
                    
                    <tr>
                         <td>
                               <label>	Sort-Code</label>
                         </td>
                         <td>
                               <input type="text" name="SortCode"  id="	Sort-Code" size="50" maxlength="50"/>
                         </td>
                    </tr>
                    <tr>
                         <td>
                                <label>User Name</label>
                         </td>
                         <td>
                               <input type="text" name="UserName" id="UserName" size="50" maxlength="20"/>
                         </td>
                    </tr>
                    <tr>
                         <td>
                              <input type="submit" name="submitted" id="Register" value="Register" />
                         </td>
                         <td>
                              <input type="reset" name="Clear" id="Clear Data" value="Clear Data"/>
                         </td>
                    </tr>
                    </table>
                    </form>   
            </div>
        
        	<div class="cleaner"></div>
        </div>
        
        <div class="cleaner"></div>        
    </div>

</div>

<div id="templatemo_footer_wrapper">

	<div id="templatemo_footer">
	  <div class="cleaner_h20"></div>
        
        <div class="section_w860">
        	Copyright © 2024 <a href="#">Your Company Name</a> | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
        </div>
            
  </div> <!-- end of footer -->
</div>
</body>
</html>