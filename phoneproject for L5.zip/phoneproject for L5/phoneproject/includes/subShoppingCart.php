<table class="sub-shoppingCart">
	<tr>
    	<td style="width:100px;">
	        <img src="<?php echo $row['ItemImage']; ?>" width="100px" height="100px"/>
        </td>
        <td style="vertical-align:top;text-align:left;padding:0 5 0 10;">
        	<p>
			<strong><?php echo $row['Description']; ?></strong><br/>
            <?php echo $row['Category']; ?>,&nbsp;<?php echo $row['SubCategory']; ?><br/>
            Quantity : <?php echo $quantity; ?>,&nbsp;
            Price : $ <?php echo $row['Price']; ?>,&nbsp;
            Amount : $ <?php echo $amount; ?><br/>
            <a href="ShoppingCart.php?ItemID=<?php echo $itemID ?>&Action=Remove">Remove</a>
            </p>
        </td>
    </tr>    
</table>