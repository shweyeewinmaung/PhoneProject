<?php
	class ShoppingCart
{
	//Constructor
	public function _construct()
	{
		if (!isset($_SESSION['ShoppingCart']))
		{
			//Creating Session "Array"
			$_SESSION['ShoppingCart']=array();	
		}
	}

	//Function to "Total Amount"
	function Get_TotalAmount()
	{
		$size=count($_SESSION['ShoppingCart']);					
		$totalAmount=0;
	
		for($i=0;$i<$size;$i++)
		{			
			$ItemID=$_SESSION['ShoppingCart'][$i]['ItemID'];
			$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];								
			
			$sql="SELECT * FROM item WHERE ItemID='$ItemID'";	
			$result=mysql_query($sql) or die(mysql_error());
			$row=mysql_fetch_array($result);
			
			$amount= $Quantity * $row['Price'];
			$totalAmount+=$amount;
		}
		return $totalAmount;
	}
	
	function Insert($ItemID,$Quantity)
	{												
		//Function Call to check
		//If the "Item" already existed in "Session"
		$index=$this->IndexOf($ItemID);
		
		//index=1 means "Item" is not existed in "Session"
		if ($index==-1)
		{
			//Get "ShoppingCart" session array size
			$size=count($_SESSION['ShoppingCart']);
			
			$_SESSION['ShoppingCart'][$size]['ItemID']=$ItemID;
			$_SESSION['ShoppingCart'][$size]['Quantity']=$Quantity;
		}
		else
		{
			$_SESSION['ShoppingCart']=array();
			$_SESSION['ShoppingCart'][0]['ItemID']=$ItemID;
			$_SESSION['ShoppingCart'][0]['Quantity']=$Quantity;
		}								
	}	
	
		
	function Remove($ItemID)
	{
		$index=$this->IndexOf($ItemID);
		
		echo "itemID: $itemID " . " Index : $index";
		
		if ($index>-1)
		{
			unset($_SESSION['ShoppingCart'][$index]);
		}
		
		$_SESSION['ShoppingCart']=array_values($_SESSION['ShoppingCart']);
	}
	
	function Clear()
	{
		unset($_SESSION['ShoppingCart']);
	}
	
	function IndexOf($ItemID)
	{
		if (!isset($_SESSION['ShoppingCart']))
			return -1;
			
		$size=count($_SESSION['ShoppingCart']);
		
		if ($size==0)
			return -1;
			
		for ($i=0;$i<$size;$i++)
		{
			if ($ItemID==$_SESSION['ShoppingCart'][$i]['ItemID'])
				return $i;
		}
		
		return -1;
	}			
}
?>