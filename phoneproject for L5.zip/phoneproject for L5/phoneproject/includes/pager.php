<?php
class pager
{
	public $pageSize,$currentPageIndex;
	/*public $searchExpression,$sortExpression;*/
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{	
		//Page Size
		$this->pageSize=$pageSize;	
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
		/*
		$this->searchBy=$searchExpression;
		$this->searchKey=$sortExpression;
		*/		
	}	
	
	function Get_SQL($tableName,$searchExpression,$sortExpression)
	{
		if (!empty($searchExpression))
		{
			$searchExpression= " WHERE " . $searchExpression;
		}			
		
		//If no search key is defined
		if (!empty($searchExpression))		
			$sql="SELECT * FROM $tableName " .								
				"$searchExpression " .
				"ORDER BY $sortExpression " .
				"LIMIT $this->offset,$this->pageSize";				
		else		
			$sql="SELECT * FROM $tableName " .
				"ORDER BY $sortExpression " .
				"LIMIT $this->offset,$this->pageSize";
			
		return $sql;
	}
	
	function Get_Data($tableName,$searchExpression,$sortExpression)
	{
		$sql=$this->Get_SQL($tableName, $searchExpression, $sortExpression);						
		
		//Calcuate "TotalRecordCount"								
		$this->totalRecordCount=
			$this->Get_TotalRecordCount($tableName,$searchExpression);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);		
		
		$result=mysql_query($sql) or die(mysql_error());
		return $result;
	}
	/********************************************************************/	
	function Get_TotalRecordCount($tableName,$searchExpression)
	{
		if (!empty($searchExpression))
		{
			$searchExpression= " WHERE " . $searchExpression;
		}
		
		//If no search key is defined
		if (empty($searchExpression))	
			$sql_RecCount="SELECT COUNT(*) AS TotalRecordCount " .				
					"FROM $tableName";												
		else
			$sql_RecCount="SELECT COUNT(*) AS TotalRecordCount " .
					"FROM $tableName " . 
					"$searchExpression";
		
		$result=mysql_query($sql_RecCount) or die(mysql_error());
		$row=mysql_fetch_array($result);
		$totalRecordCount=$row['TotalRecordCount'];	
		
		return $totalRecordCount;					
	}
	/********************************************************************/
	function Generate_Pager()
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		/********************************************************************/
		// "Previous" and "First" page link
		if ($this->currentPageIndex>1)
		{
			$pageIndex=$this->currentPageIndex-1;					
			echo "<a href='$self?page=1'>[First]</a>&nbsp;";
			echo "<a href='$self?page=$pageIndex'>[Prev]</a>&nbsp;";							
		}
		else
		{}								
		/********************************************************************/
		// print the link to access each page
		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				echo $i . "&nbsp;";
			}
			else
			{
				echo "<a href='$self?page=$i'>$i</a>&nbsp;";
			}
		}
		/********************************************************************/
		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			echo "<a href='$self?page=$pageIndex'>[Next]</a>&nbsp;";
			echo "<a href='$self?page=$this->maxPage'>[Last]</a>&nbsp;";
		}
		else
		{}
		/********************************************************************/
	}
	/********************************************************************/
}	
?>