<?php
	if (empty($itemID))
		die("No Record");
?>
<table class="sub-itemDisplay">

	<tr>
    	<td style="text-align:center;padding:3px;">        	
        	<img src="<?php echo $row['ItemImage']; ?>" width="100px" height="100px"/>
        </td>
    </tr>
    
    <tr>
    	<td style="font-weight:bold;">
	    	<?php echo $row['Description']; ?>
        </td>
    </tr>

	<tr>
    	<td>
        	<?php echo $row['Category']; ?>, 
	    	<?php echo $row['SubCategory']; ?>
        </td>
    </tr>
    
    <tr>
        <td>
        	<?php echo $row['ShopName']; ?>
        </td>
    </tr>
    
    <tr>
        <td>
        	$ <?php echo $row['Price']; ?>
        </td>
    </tr>
    
    <tr>
        <td>
			<?php    
			$objLogIn=new LogIn();    				
			if ($objLogIn->isMemberLogIn())
			{
				if ($action==="MyItem")
				{
			?>
                    <a href="stockIn.php?ItemID=<?php echo $row['ItemID'];?>">Stock In</a>&nbsp;
                    <a href="itemUpdate.php?ItemID=<?php echo $row['ItemID'];?>">Update</a>
			<?php
				}
				else
				{
			?>
                    <a href="ShoppingCart.php?ItemID=<?php echo $row['ItemID'];?>&Action=Add">Add 2 Cart</a>
            <?php
				}
			}
			?>
        </td>                                
    </tr>
</table>