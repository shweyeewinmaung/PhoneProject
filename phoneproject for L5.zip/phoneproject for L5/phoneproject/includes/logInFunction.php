<?php
class LogIn
{
	function isLogInOK($UserName,$Password)
	{
		$sql="SELECT * FROM customer " .
				"WHERE UserName='$UserName' " .
				"AND Password='$Password'";
				
		$result=mysql_query($sql) or die(mysql_error());		
		$numOfRows=mysql_num_rows($result);

		if ($numOfRows==0)
			return false;
		else
		{
			$row=mysql_fetch_array($result); 
			$CustomerID=$row['CustomerID'];
			$Role=$row['Role'];			
			
			$_SESSION['customer']['CustomerID']=$CustomerID;
			$_SESSION['customer']['UserName']=$UserName;
			$_SESSION['customer']['Password']=$Password;
			$_SESSION['customer']['Role']=$Role;

			if ($role==="ADMIN")
				header("Location:MemberIndex.php");
			else
				header("Location:AdminIndex.php?" . $UserName);
			return true;
		}
	}

	function getUserID()
	{
		if (!isset($_SESSION['customer']))
			return "";

		if (!isset($_SESSION['customer']['CustomerID']))
			return "";

		return $_SESSION['customer']['CustomerID'];
	}

	function getUserName()
	{
		if (!isset($_SESSION['customer']))
			return "";

		if (!isset($_SESSION['customer']['UserName']))
			return "";

		return $_SESSION['customer']['UserName'];
	}
	
	function isAdminLogIn()
	{
		return $this->isLoggedIn("ADMIN");
	}
	
	function isMemberLogIn()
	{
		return $this->isLoggedIn("MEMBER");
	}
	
	function isLoggedIn($role)
	{
		if (!isset($_SESSION['customer']))
			return false;

		if (!isset($_SESSION['customer']['Role']))
			return false;			
			
		//Checking "role"
		//such as "member" or "admin"			
		if ($role!==$_SESSION['customer']['Role'])
			return false;
			
		return true;
	}
}
?>