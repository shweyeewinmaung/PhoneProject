<?php
function Get_Date($value)
{
	$date=date("Y-m-d",strtotime($value));
	return $date;
}

function Get_Month($value)
{	
	$month=date("m",strtotime($value));
	return (int)$month;
}
?>