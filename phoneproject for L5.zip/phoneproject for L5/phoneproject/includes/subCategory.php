<?php	
	require_once("includes/db.php");
	require_once("includes/function.php");
	
	$sql_temp="SELECT * FROM SubCategory " .
			"WHERE CategoryID='$categoryID'";
	
	$result_temp=mysql_query($sql_temp) or die(mysql_error());	
	$noOfRows_temp=mysql_num_rows($result_temp);	
?>
	<table class="subCategoryTable">
		<tr>
			<th>
				<?php echo $category;?>
			</th>
		</tr>	
		<?php
		for ($k=0;$k<$noOfRows_temp;$k++)
		{
			$row_temp=mysql_fetch_array($result_temp); 
		?>		
		<tr>
			<td>
				<?php
				if ($action==="select")
				{ 
					$link="item.php?CategoryID=" . $row_temp['CategoryID'] .						
						"&SubCategoryID=" . $row_temp['SubCategoryID'] .
						"&ShopID=" . $shopID . "&ShopName=" . $shopName;
				?>
					<a href="<?php echo $link?>"><?php echo $row_temp['SubCategory']?></a>
				<?php
				}
				else  
				{
					echo $row_temp['SubCategory'];
				} 
				?>			
			</td>
		</tr>
		<?php
		} 
		?>
	</table>