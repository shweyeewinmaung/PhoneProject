<?php
	session_start();

	require_once("includes/db.php");
	require_once("includes/function.php");	
	require_once("includes/logInFunction.php");		


		$ItemID=$_GET['ItemID'];
		
		$sql="Delete  from `item` " .
						"WHERE ItemID='$ItemID'";
	
		mysql_query($sql) or die(mysql_error());	
		
		$message="\"" . $ItemID . "\" is successfully deleted.";
		

?>